</div>

        <!-- Main Footer -->
        <footer class="main-footer" style="max-height: 100px;">
            <strong>Copyright © 2018 <a href="#">The GRAIN Network</a>.</strong> All Rights Reserved.
        </footer>

    </div>
    

    <!--notification Modal -->
   <div class="modal fade" id="notificationmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
        <h4 class="modal-title" id="myModalLabel"></h4>
      </div>
      <div class="modal-body">

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>


    
    
    <script src="assets/js/jQuery-3.js"></script>
    <script src="assets/js/jquery-printme.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script type="text/javascript" src="assets/js/jquery-ui.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
	    <script src="assets/js/jquery.js"></script>
    <script src="assets/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>

    <!-- Bootstrap 3.3.5 -->
    <script type="text/javascript" src="assets/js/bootstrap.js"></script>
	

    <!-- Slimscroll -->
   <!-- DataTables -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>

    <!-- Select2 -->
    <!-- Select2 -->
    <script src="assets/js/select2.js"></script>
    <script src="assets/js/icheck.js"></script>
    <!-- FastClick -->
	
	

    <script src="assets/js/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="assets/js/app.js"></script>
    <script src="assets/js/bootstrapValidator.js"></script>
					  <script src="js/datatables.min.js"></script>


       <script src="js/table-datatables-buttons.min.js"></script>

	          <script src="js/datatables.bootstrap.js"></script>



<script type="text/javascript">
        $(function () {
            //bootstrap WYSIHTML5 - text editor
            $(".bswysiwyg").wysihtml5({
              toolbar: {
                "image": false, //Button to insert an image. Default true,
                "color": true
              }
            });
        });
    </script>


</body></html>