<?php include 'includes/dbpipe.php'; ?>
<?php 
 $title = "Dashboard"; 
 ?>
<?php include 'member.base.php'; ?>
 
 <body class="skin-blue sidebar-mini">
<!--<body class="hold-transition skin-red sidebar-mini">-->
  <!-- Overlay  -->
  <div id="overlay" style="background-color: #ecf0f5;opacity: 0.5;z-index: 2000;position: absolute;left: 0;top: 0;width: 100%;height: 100%;display: none;">
    <i style="position: fixed;width: auto;height: auto;z-index: 15;top: 20%;left: 45%;" class="fa fa-spinner fa-spin fa-5x fa-bw"></i>
  </div>

    <div class="wrapper">
        <!-- Main Header -->
        <?php include 'main-header.php'; ?>
        <!-- Left side column. contains the logo and sidebar -->
		
		<?php include 'member-sidebar.php'; ?>
                <!-- Content Wrapper. Contains page content -->
         <div class="content-wrapper" style="background-image: url('cy.jpg');background: rgba(38, 57, 88, 0.89);
        min-height: 500px;color">

    <!-- Content Header (Page header) -->
    <section class="content-header" style="color:white;">
        <h1 style="color:white;"><b>
            Administrator Dashboard
        </b></h1>
        <ol class="breadcrumb">
            <li class="active" style="color:white;"><i class="fa fa-dashboard"></i> Administrator Dashboard</li>
        </ol>
    </section> <!-- End Content Header (Page header) -->
<strong>
    <!-- Main content -->
    <section class="content">
	<div class="row">
							            <div class="col-md-12 col-sm-12 col-md-12">

        <!-- Small boxes (Stat box) -->
        <div class="row">

            <div class="col-lg-6 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <p><b>Add New Admin</b></p>
                    </div>
                    <a href="AddAdmin" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div> <!-- End small box -->
            </div>
            <div class="col-lg-6 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-yellow">
                    <div class="inner">
                        <p><b>Write New Notification Message</b></p>
                    </div>
                    <a href="WriteNotice" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div> <!-- End small box -->
            </div>
        </div> <!-- End Small boxes (Stat box) -->
<?php
	 $result14 = mysqli_query($con,"SELECT * FROM members");
		 $user_count = mysqli_num_rows($result14);
			?>

        <!-- Info Boxes -->

        <div class="row">

		<div class="panel panel-shadow" data-collapsed="0">
                        <div class="panel-heading bg-green">
                            <div class="panel-title"><i class="fa fa-users"></i><strong>  User Statistics</strong></div>
                        </div>
					                        <div class="panel-body">

            <div class="col-sm-4">
                <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>
                     <!-- Info-box-content -->
                    <div class="info-box-content">
															<a href="UsersList" class="">

                        <span class="info-box-text">Total Users</span>
                        <span class="info-box-number"><b><?php echo $user_count; ?></b></span>
						</a>
                    </div> <!-- End info-box-content -->
                </div>
            </div>
			<?php
	 $result111 = mysqli_query($con,"SELECT * FROM members where status='active'");
		 $active_count = mysqli_num_rows($result111);
			?>

            <div class="col-sm-4">
                <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-check-square-o"></i></span>
                     <!-- Info-box-content -->
                    <div class="info-box-content">
										<a href="ActiveUser" class="">

                        <span class="info-box-text">Active Users</span>
                        <span class="info-box-number"><b><?php echo $active_count; ?></b></span>
						</a>
                    </div> <!-- End info-box-content -->
                </div>
            </div>
			<?php
	 $result112 = mysqli_query($con,"SELECT * FROM members where status='blocked'");
		 $block_count = mysqli_num_rows($result112);
			?>

            <div class="col-sm-4">
                <div class="info-box">
                    <span class="info-box-icon bg-red"><i class="fa fa-ban"></i></span>
                     <!-- Info-box-content -->
                    <div class="info-box-content">
					<a href="BlockedUser" class="">
                        <span class="info-box-text">Blocked Users</span>
                        <span class="info-box-number"><b><?php echo $block_count; ?></b></span>
						</a>
                    </div> <!-- End info-box-content -->
                </div>
            </div>
			</div>
			</div>
        </div> <!-- End Info Boxes -->

        <!-- Extras -->
        <div class="row">
		<div class="panel panel-shadow" data-collapsed="0">
                        <div class="panel-heading bg-blue">
                            <div class="panel-title"><i class="fa fa-desktop"></i><strong> Setting, Security and Admin</strong></div>
                        </div>
					      <div class="panel-body">

		<div class="col-sm-3">
                <a href="AppSettings" class="btn btn-lg btn-block btn-danger btn-flat">System Settings & Site Info</a>
            </div>
           <div class="col-sm-3">
			   <a href="ChangePassword" class="btn btn-lg btn-block btn-info btn-flat"><i class="fa fa-unlock"></i> Change Password</a>
            </div>
           <div class="col-sm-3">
                <a href="AdminList" class="btn btn-lg btn-block btn-warning btn-flat"><i class="fa fa-users"></i> Admin List</a>
            </div>
			<div class="col-sm-3">
                <a href="PaymentMethod" class="btn btn-lg btn-block btn-warning btn-flat"><i class="fa fa-cc-mastercard"></i> Payment Methods</a>
            </div>
		
		</div>
		</div>
        </div> <!-- End Extras -->
        <div class="row">
		<div class="panel panel-shadow" data-collapsed="0">
                        <div class="panel-heading " style="background:indigo;color:white">
                            <div class="panel-title"><i class="fa fa-credit-card"></i><strong> Payment References</strong></div>
                        </div>
					                        <div class="panel-body">

            <div class="col-sm-4">
                <a href="ConfirmedWithdrawal" class="btn btn-lg btn-block btn-success"><i class="fa fa-money"></i> Confirmed ROI Withdraw</a>
            </div>
			
			<div class="col-sm-4">
                <a href="PendingWithdrawal" class="btn btn-lg btn-block btn-warning btn-flat"><i class="fa fa-money"></i> Pending ROI Withdraw</a>
            </div>
			<div class="col-sm-4">
                <a href="PendingPILRequest" class="btn btn-lg btn-block btn-danger"><i class="fa fa-money"></i> Pending PIL Withdrawals</a>
            </div>
			
			</div>
			</div>
        </div>
		 <div class="row">
		<div class="panel panel-shadow" data-collapsed="0">
                        <div class="panel-heading " style="background:navy;color:white">
                            <div class="panel-title"><i class="fa fa-credit-card"></i><strong> Package Tracking</strong></div>
                        </div>
					                        <div class="panel-body">

            <div class="col-sm-4">
                <a href="InactivePackage" class="btn btn-lg btn-block btn-success"><i class="fa fa-money"></i> Inactive Package Accounts</a>
            </div>
			
			<div class="col-sm-4">
                <a href="ActivePackage" class="btn btn-lg btn-block btn-warning btn-flat"><i class="fa fa-money"></i> Active Package Accounts</a>
            </div>
			<div class="col-sm-4">
                <a href="ConfirmedPILRequest" class="btn btn-lg btn-block btn-info"><i class="fa fa-money"></i> Confirmed PIL Withdrawals</a>
            </div>
			
			</div>
			</div>
        </div>
<?php
	$sql = mysqli_query($con,"SELECT SUM(with)amount) AS amountTotal FROM withdraw where status='active'");
     while ($array = mysqli_fetch_array($sql)) {
	if($array['amountTotal'] > '0'){
		$totalAllGhSukses = $array['amountTotal'];
	}
	else{
		$totalAllGhSukses = '0';
	}
}
   
	?>	
	
	<?php
	$sql = mysqli_query($con,"SELECT SUM(amount) AS amountTota FROM sub_package where status='active'");
     while ($array = mysqli_fetch_array($sql)) {
	if($array['amountTota'] > '0'){
		$totalAllPhSukses = $array['amountTota'];
	}
	else{
		$totalAllPhSukses = '0';
	}
}
   
	?>	
  

        <!-- Info Boxes -->
        <div class="row">
		<div class="panel panel-shadow" data-collapsed="0">
                        <div class="panel-heading bg-blue">
                            <div class="panel-title"><i class="fa fa-list"></i><strong> Overall Payment Statistics</strong></div>
                        </div>
					      <div class="panel-body">

		
            <div class="col-sm-6">
                <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="fa fa-money"></i></span>
                     <!-- Info-box-content -->
                    <div class="info-box-content">
                        <span class="info-box-text"><b>Total Package Payment</b></span>
                        <span class="info-box-number">$<?php echo (number_format($totalAllPhSukses)); ?></span>
                    </div> <!-- End info-box-content -->
                </div>
            </div>
            <div class="col-sm-6">
                <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-money"></i></span>
                     <!-- Info-box-content -->
                    <div class="info-box-content">
                        <span class="info-box-text"><b>Total Withdraw Payment</b></span>
                        <span class="info-box-number">$<?php echo (number_format($totalAllGhSukses)); ?></span>
                    </div> <!-- End info-box-content -->
                </div>
            </div>
			</div>
			</div>
        </div> <!-- End Info Boxes -->
</div>
</div>
    </section>
<?php include 'member-footer.php'; ?>
