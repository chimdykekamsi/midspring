<!-- Left side column. contains the logo and sidebar -->
 <aside class="main-sidebar" id="sidebar-wrapper">
<?php
  include 'includes/dbpipe.php';
$user_query = mysqli_query($con, "select id, name from admins where id='$session_id'")or die(mysqli_error());
	$rows = mysqli_fetch_array($user_query);
		
?>

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      	<!-- Sidebar user panel -->
      	<div class="user-panel">
        	<div class="pull-left image">
				<img src="assets/images/avatar_m.png" class="img-circle" alt="User Image">
			</div>
        	<div class="pull-left info">
          		<p><b><?php echo $rows['name']; ?></b></p>
        	</div>
      	</div> <!-- End Sidebar user panel -->

      	<!-- sidebar menu: : style can be found in sidebar.less -->
      	<ul class="sidebar-menu">
        	<li class="header">MAIN NAVIGATION</li>
			
		        <li>
		          	<a href="dashboard">
		            	<i class="fa fa-dashboard"></i> <span> Dashboard</span>
		          	</a>
		        </li>
				<li>
		          	<a href="InactivePackage">
		            	<i class="fa fa-warning"></i> <span>Pending Members Package</span>
		            	<span class="pull-right-container">
		              		<small class="label pull-right bg-orange"></small>
		            	</span>
		          	</a>
		        </li>
	        <li>
		          	<a href="ActivePackage">
		            	<i class="fa fa-check-square-o"></i> <span>Active Members Package</span>
		            	<span class="pull-right-container">
		              		<small class="label pull-right bg-orange"></small>
		            	</span>
		          	</a>
		        </li>
<li class="treeview">
    <a href="#">
        <i class="fa fa-money"></i>
        <span>Payments Section</span>
        <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu">
	    <li><a href="PendingWithdrawal"><i class="fa fa-money"></i>Pending Withdrawal Request</a></li>
       
		<li><a href="PendingPILRequest"><i class="fa fa-money"></i>Pending PIL Withdrawal Request</a></li>
		 <li><a href="ConfirmedWithdrawal"><i class="fa fa-money"></i>Confirmed Withdrawal Request</a></li>
				<li><a href="ConfirmedPILRequest"><i class="fa fa-money"></i>Confirmed PIL Withdrawal Request</a></li>



         </ul>
</li>

				<?php
	 $result112 = mysqli_query($con,"SELECT * FROM support where status='blank'");
		 $tick_count = mysqli_num_rows($result112);
			?>

			
			<li class="treeview">
    <a href="#">
        <i class="fa fa-users"></i>
        <span>Manage Users</span>
        <i class="fa fa-angle-left pull-right"></i>
    </a>
    <ul class="treeview-menu">
        <li><a href="UsersList"><i class="fa fa-user"></i>All USers</a></li>
        <li><a href="BlockedUser"><i class="fa fa-ban"></i>Blocked Users</a></li>
		<li><a href="ActiveUser"><i class="fa fa-check-square-o"></i>Active Users</a></li>
		        <li><a href="ActiveUserIdentity"><i class="fa fa-users"></i>Active User Identity</a></li>




         </ul>
</li>
<li>
		          	<a href="PILList">
		            	<i class="fa fa-ticket"></i> <span>PIL Count Per Users</span>
		            	<span class="pull-right-container">
		              		<small class="label pull-right bg-orange"></small>
		            	</span>
		          	</a>
		        </li>
			
	        	<li>
		          	<a href="SupportTicket">
		            	<i class="fa fa-ticket"></i> <span>Support Tickets</span>
		            	<span class="pull-right-container">
		              		<small class="label pull-right bg-orange"><?php echo $tick_count; ?></small>
		            	</span>
		          	</a>
		        </li>
	        
	      			<li>
	          	<a href="Notifications">
	            	<i class="fa fa-bell"></i> <span>Notifications</span>
	          	</a>
	        </li>
	       
	        <li>
	        	<a href="logout">
	        		<i class="fa fa-sign-out"></i> <span>Logout</span>
	        	</a>
	        </li>
        </ul> <!-- End sidebar menu: : style can be found in sidebar.less -->

    </section> <!-- End sidebar -->

</aside> <!-- End Left side column -->