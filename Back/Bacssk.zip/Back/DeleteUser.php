  <?php include 'includes/dbpipe.php'; ?>
  <?php include 'includes/auth.php'; ?>
  <?php
		if(isset($_GET['render'])) {
			
		$id = $_GET['render'];
			 
		 
	          @mysqli_query($con, "DELETE FROM members WHERE id='$id'");
		
		
				header("Location: UsersList");

				}
		?>

  